% Computes the total error of the graph
function Fx = compute_global_error(g)

Fx = 0;

% Loop over all edges
for eid = 1:length(g.edges)
  edge = g.edges(eid);

  % pose-pose constraint
  if (strcmp(edge.type, 'P') != 0)

    x1 = v2t(g.x(edge.fromIdx:edge.fromIdx+2));  % the first robot pose
    x2 = v2t(g.x(edge.toIdx:edge.toIdx+2));      % the second robot pose

    % compute the error of the constraint and add it to Fx.
    % Use edge.measurement and edge.information to access the measurement and the information matrix respectively.

    e = t2v(invt(v2t(edge.measurement)) * invt(x1) * x2);
    Fx += e' * edge.information * e;

  % multimodal pose-pose cosntraint
  elseif (strcmp(edge.type, 'M') != 0)

	% compute the most likely mode and its error after implementing the function compute_best_mixture_component
	[best_mode, best_error] = compute_best_mixture_component(edge,g.x);

	%TODO: compute the corresponding squared error and add it to Fx


  endif

end
