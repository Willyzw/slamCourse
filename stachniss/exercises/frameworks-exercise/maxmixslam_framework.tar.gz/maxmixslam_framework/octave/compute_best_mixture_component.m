% Compute the most likely mode of a constraint, i.e. the one that minimizes the error
%
% x is the state vector containing all poses: [x1; y1; theta1; x2; y2; theta2; ...]
% edge is a pose-pose constraint with the following components:
% edge.type
% edge.weight(i): weight of i-th mode
% edge.fromIdx(i): index to the first element of the first pose of the i-th mode
% edge.toIdx(i): index to the first element of the second pose of the i-th mode
% edge.measurement{i}: the measurement of the i-th mode
% edge.information{i}: the information matrix of the i-th mode
%
% Output
% best_mode: the most likely mode from {1,...,|modes|}
% best_error: the error corresponding to the most likely mode

function [best_mode, best_error] = compute_best_mixture_component(edge, x)

    min_neg_log_prob = Inf;
    best_mode = -1;

    % TODO: iterate over all modes and return the one with the least negative log likelihood
    % as well as its corresponding error vector
    for(mode=1:length(edge.fromIdx))


    endfor

end
