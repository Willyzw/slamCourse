% plot a 2D SLAM graph
function plot_graph(g, iteration = -1)

clf;
hold on;

pIdxX = 1:3:rows(g.x);
pIdxY = 2:3:rows(g.x);
plot(g.x(pIdxX), g.x(pIdxY), '.xb', 'markersize', 4);
axis equal

hold off;

figure(1, "visible", "on");
drawnow;
%pause(0.1);
if (iteration >= 0)
  filename = sprintf('../plots/lsslam_%03d.png', iteration);
  print(filename, '-dpng');
end


end
