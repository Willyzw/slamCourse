% read a g2o data file describing a max-mixture data set
function graph = read_mixture_graph(filename)

fid = fopen(filename, 'r');

%{
graph = struct (
  'x', [],
  'edges', []
);
%}
graph = struct (
  'x', [],
  'edges', []
);

disp('Parsing File');
while true
  ln = fgetl(fid);
  if (ln == -1)
    break;
  end
  tokens = strsplit(ln, ' ', true);
  double_tokens = str2double(tokens);

  tk = 2;
  if (strcmp(tokens(1), 'VERTEX_SE2') != 0)
    % assuming that it starts at 0 and goes up to n
    % if not, would need a lookup structure
    id = int32(double_tokens(tk++)) + 1;
    values = double_tokens(tk:tk+2)'; tk += 3;
    graph.x = [graph.x; values];

  elseif (strcmp(tokens(1), 'EDGE_SE2_MIXTURE') != 0)
    tk += 2;
    num_modes = int32(double_tokens(tk++));
    
    mmEdge = struct(
      'type', 'M',
      'weight', zeros(num_modes, 1),
      'fromIdx', zeros(num_modes, 1),
      'toIdx', zeros(num_modes, 1),
      'measurement', [],
      'information', []
    );

    for m = 1:num_modes
      ident = tokens(tk++);
      if (strcmp(ident, 'EDGE_SE2') == 0)
        disp('Something wrong with parsing');
      end

      mmEdge.weight(m) = double_tokens(tk++);
      mmEdge.fromIdx(m) = 3*double_tokens(tk++) + 1;
      mmEdge.toIdx(m) = 3*double_tokens(tk++) + 1;
      mmEdge.measurement{m} = double_tokens(tk:tk+2); tk += 3;
      uppertri = double_tokens(tk:tk+5)'; tk += 6;
      information = [uppertri(1), uppertri(2), uppertri(3);
                     uppertri(2), uppertri(4), uppertri(5);
                     uppertri(3), uppertri(5), uppertri(6)];
      mmEdge.information{m} = information;
    end

    graph.edges = [graph.edges; mmEdge];

  elseif (strcmp(tokens(1), 'EDGE_SE2') != 0)
    fromId = 3*int32(double_tokens(tk++)) + 1;
    toId = 3*int32(double_tokens(tk++)) + 1;
    measurement = double_tokens(tk:tk+2)'; tk += 3;
    uppertri = double_tokens(tk:tk+5)'; tk += 6;
    information = [uppertri(1), uppertri(2), uppertri(3);
                   uppertri(2), uppertri(4), uppertri(5);
                   uppertri(3), uppertri(5), uppertri(6)];
    graph.edges = [graph.edges; struct(
      'type', 'P',
      'weight', ones(1,1),
      'fromIdx', fromId,
      'toIdx', toId,
      'measurement', measurement,
      'information', information)];
  end

end
disp('done');

end
