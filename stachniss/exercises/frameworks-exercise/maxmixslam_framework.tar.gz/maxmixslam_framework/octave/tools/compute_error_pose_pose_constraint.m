% Compute the error of a pose-pose constraint
% x1 3x1 vector (x,y,theta) of the first robot pose
% x2 3x1 vector (x,y,theta) of the second robot pose
% z 3x1 vector (x,y,theta) of the measurement
%
% Output
% e 3x1 error of the constraint
function [e] = compute_error_pose_pose_constraint(x1, x2, z)

  % compute the error

  zt_ij = v2t(z);
  vt_i  = v2t(x1);
  vt_j  = v2t(x2);

  ztinv = invt(zt_ij);
  e = t2v(ztinv * invt(vt_i) * vt_j);

end;
