% Compute the Jacobian components of a pose-pose constraint
% x1 3x1 vector (x,y,theta) of the first robot pose
% x2 3x1 vector (x,y,theta) of the second robot pose
% z 3x1 vector (x,y,theta) of the measurement
%
%
% Output
% A 3x3 Jacobian wrt x1
% B 3x3 Jacobian wrt x2
function [A, B] = linearize_pose_pose_constraint(x1, x2, z)

  % compute the Jacobians

  zt_ij = v2t(z);
  vt_i  = v2t(x1);
  vt_j  = v2t(x2);

  s = sin(x1(3));
  c = cos(x1(3));
  Ri = vt_i(1:2, 1:2);
  Rij = zt_ij(1:2, 1:2);
  dRiTransposed_dTheta = [-s c; -c -s];
  delta_t = x2(1:2) - x1(1:2);

  A = [ - Rij' * Ri', Rij' * dRiTransposed_dTheta * delta_t;
       0, 0, -1];
  B = [Rij' * Ri', [0;0];
       0, 0, 1];

end;
