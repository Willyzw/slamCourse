% performs one iteration of the Gauss-Newton algorithm
% each constraint is linearized and added to the Hessian

function dx = linearize_and_solve(g)

nnz = nnz_of_graph(g);

% allocate the sparse H and the vector b
H = spalloc(length(g.x), length(g.x), nnz);
b = zeros(length(g.x), 1);

needToAddPrior = true;

% compute the addend term to H and b for each of our constraints
disp('linearize and build system');
for eid = 1:length(g.edges)
  edge = g.edges(eid);

  % pose-pose constraint
  if (strcmp(edge.type, 'P') != 0)
    % edge.fromIdx and edge.toIdx describe the location of
    % the first element of the pose in the state vector
    % edge.measurement is the measurement
    % edge.information is the information matrix

    x1 = g.x(edge.fromIdx:edge.fromIdx+2);  % the first robot pose
    x2 = g.x(edge.toIdx:edge.toIdx+2);      % the second robot pose

    % Computing the error and the Jacobians
    % e the error vector
    % A Jacobian wrt x1
    % B Jacobian wrt x2
    [A, B] = linearize_pose_pose_constraint(x1, x2, edge.measurement);
    [e] = compute_error_pose_pose_constraint(x1, x2, edge.measurement);


    % compute and add the required terms to H and b

    % computing the terms
    b_i  = A' * edge.information * e;
    b_j  = B' * edge.information *e;
    H_ii = A' * edge.information * A;
    H_ij = A' * edge.information * B;
    H_jj = B' * edge.information * B;

    % adding them to the matrix and b
    H(edge.fromIdx:edge.fromIdx+2, edge.fromIdx:edge.fromIdx+2) += H_ii;
    H(edge.fromIdx:edge.fromIdx+2, edge.toIdx:edge.toIdx+2) += H_ij;
    H(edge.toIdx:edge.toIdx+2, edge.fromIdx:edge.fromIdx+2) += H_ij';
    H(edge.toIdx:edge.toIdx+2, edge.toIdx:edge.toIdx+2) += H_jj;

    b(edge.fromIdx:edge.fromIdx+2) += b_i;
    b(edge.toIdx:edge.toIdx+2) += b_j;

    if (needToAddPrior)
      % add the prior for one pose of this edge
      % This fixes one node to remain at its current location
       H(1:3, 1:3) += 1000.0*eye(3);      
      needToAddPrior = false;
    end

  % multimodal pose-pose constraint
  elseif (strcmp(edge.type, 'M') != 0)
    % edge.weight(i): weight of i-th mode
    % edge.fromIdx(i): index to the first element of the first pose of the i-th mode
    % edge.toIdx(i): index to the first element of the second pose of the i-th mode
    % edge.measurement{i}: the measurement of the i-th mode
    % edge.information{i}: the information matrix of the i-th mode
    % edge.measurement is the measurement
    % edge.information is the information matrix

	% TODO: compute the most likely mode and its error after implementing the function compute_best_mixture_component
	

	% TODO: compute the corresponding Jacobian blocks
	
	
    	% TODO: compute and add the required terms to H and b
    	% computing the terms


  endif
end

disp('solving system');

% solve the linear system, whereas the solution should be stored in dx
% Remember to use the backslash operator instead of inverting H
dx = -H\b;

end
