function [mu, sigma] = nva_recover_gaussian(sigma_points, w_m, w_c)
% This function computes the recovered Gaussian distribution (mu and sigma)
% given the sigma points (size: nx2n+1) and their weights w_m and w_c:
% w_m = [w_m_0, ..., w_m_2n], w_c = [w_c_0, ..., w_c_2n].
% The weight vectors are each 1x2n+1 in size,
% where n is the dimensionality of the distribution.

% Try to vectorize your operations as much as possible

% TODO: compute mu
w = zeros(size(sigma_points));
w(:,1) = w_m(1);
w(:,2:end) = w_m(2);
temp = sigma_points.*w;
mu = sum(temp,2);

n = length(mu);

% TODO: compute sigma

diff = sigma_points-repmat(mu,1,2*n+1);

sigma = zeros(n);
for i=1:2*n+1
sigma = sigma + w_c(i)*diff(:,i)*diff(:,i)';
endfor

end
