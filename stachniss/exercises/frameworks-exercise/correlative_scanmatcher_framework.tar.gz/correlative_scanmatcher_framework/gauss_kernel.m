function K = gauss_kernel(s, sigma = 0.5)

[x,y] = meshgrid(-s:s, -s:s);
radiusSquared = x.^2 + y.^2;
K = exp(-radiusSquared / (2*sigma^2));
K = K/sum(K(:));

end
