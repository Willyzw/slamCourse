% The main test procedure for the correlative scan matcher

% load in the data
load "intelFirstLoop.dat";
robotlaser = intelFirstLoop;

% prepare plotting data
odometry = zeros(3, size(robotlaser, 2));
scanmatch = odometry;

% copy first pose of the robot
odometry(:,1) = robotlaser{1}.odom';
scanmatch(:,1) = robotlaser{1}.odom';

for t = 2:size(robotlaser, 2)
  printf('time step %d\n', t);
  fflush(stdout);

  odometry(:,t) = robotlaser{t}.odom';

  % perform matching
  motion = corr_match(robotlaser{t-1}, robotlaser{t});
  smPose = v2t(scanmatch(:, t-1)) * motion;
  scanmatch(:,t) = t2v(smPose);

  % plot both odometry estimates
  plot_trajectories(odometry, scanmatch, t);
end
