function plot_trajectories(odometry, scanmatch, timestep)

clf
hold on

if (0)
  for t = 1:timestep
    plot_robot(odometry(:, t), "r");
    plot_robot(scanmatch(:, t), "b");
  end
else
  plot(odometry(1, 1:timestep), odometry(2, 1:timestep), '-r', scanmatch(1, 1:timestep), scanmatch(2, 1:timestep), '-b');
end

filename = sprintf('cm_%05d.png', timestep);
print(filename, '-dpng');
hold off

end
