function match_and_plot(robotlaserArray, index)

[motion,covariance] = corr_match(robotlaserArray{index}, robotlaserArray{index+1});
plot_match(robotlaserArray{index}, robotlaserArray{index+1}, motion, covariance);

end
