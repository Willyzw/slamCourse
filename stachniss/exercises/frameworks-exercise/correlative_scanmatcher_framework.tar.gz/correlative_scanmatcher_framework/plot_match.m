function plot_match(rl1, rl2, motion, covariance=[])

p1 = robotlaser_as_cartesian(rl1);
p2 = motion * robotlaser_as_cartesian(rl2);
if (length(covariance) == 0)
  plot(p1(1,:), p1(2,:), '*', p2(1,:), p2(2,:), '+');
else
  a = covariance(1, 1); 
  b = covariance(1, 2); 
  d = covariance(2, 2);

  %eigen-values
  D = a*d - b*b; % determinant of the matrix
  T = a+d;       % Trace of the matrix
  h = sqrt(0.25*(T*T) - D);
  lambda1 = 0.5*T + h;  % solving characteristic polynom using p-q-formula
  lambda2 = 0.5*T - h;

  theta     = 0.5 * atan2(2.0 * b, a - d);
  persistent chi = sqrt(chi2inv(0.95, 2));
  majorAxis = chi * sqrt(lambda1);
  minorAxis = chi * sqrt(lambda2);
  if (a < b)
    swap = majorAxis;
    majorAxis = b;
    minorAxis = swap;
  end

  % sample points of the ellipsoid
  angles = linspace(-pi, pi, 100);
  M = [cos(theta) -sin(theta) motion(1, 3);
       sin(theta)  cos(theta) motion(2, 3);
       0 0 1];
  ep(1,:) = majorAxis*cos(angles);
  ep(2,:) = minorAxis*sin(angles);
  ep(3,:) = 1;
  ep = M*ep;

  plot(p1(1,:), p1(2,:), '*', p2(1,:), p2(2,:), '+', ep(1,:), ep(2,:));
end

end
