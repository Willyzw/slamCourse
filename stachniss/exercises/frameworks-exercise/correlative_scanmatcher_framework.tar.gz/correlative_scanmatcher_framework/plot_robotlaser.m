function plot_robotlaser(rl, maxRange=15, pose=[])

points = robotlaser_as_cartesian(rl, maxRange);
if (length(pose) == 3)
  transf = v2t(pose);
else
  transf = v2t(rl.odom);
end
points = transf * points;
plot(points(1,:), points(2,:), "*");

end
