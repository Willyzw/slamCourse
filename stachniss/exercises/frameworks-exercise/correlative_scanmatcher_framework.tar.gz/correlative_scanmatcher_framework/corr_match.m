function[motion, covariance] = corr_match(reference, other)

% parameters
gridsize = 40;
resolution = 0.025;
rotResolution = 0.00872664625997164786;
xySearch = 0.15;
rotSearch = .17453292519943295767;
sparsifyDistance = 0.25;

maxRangeForMatching = 12;
referencePoints = robotlaser_as_cartesian(reference, maxRangeForMatching);
otherPoints     = robotlaser_as_cartesian(other, maxRangeForMatching);

% apply the odometry to the other points
odomMotionBetweenScans = t2v(inv(v2t(reference.odom)) * v2t(other.odom));

% sparse the other points
otherPoints = sparsify_points(otherPoints(1:2, :), sparsifyDistance);

% the grid containing the reference scan
numCells = int32(gridsize / resolution);
map = zeros(numCells, numCells);
gridOffset = gridsize * 0.5;

% project the points to grid coordinates
mapPoints = round((referencePoints(1:2,:) + gridOffset) / resolution);
% insert the points into the grid
map(size(map,1) * (mapPoints(2,:)-1) + mapPoints(1,:)) = 1;
% Gaussian Kernel for smoothing the map
%kernel=[2 3 2; 3 4 3; 2 3 2];
kernel = gauss_kernel(3, 2);
map = conv2(map, kernel, 'same');
%imagesc(map);
%save map.dat map;

xSteps = (-xySearch:resolution:xySearch) + odomMotionBetweenScans(1);
ySteps = (-xySearch:resolution:xySearch) + odomMotionBetweenScans(2);
thetaSteps = (-rotSearch:rotResolution:rotSearch) + odomMotionBetweenScans(3);

K = zeros(3, 3);
u = zeros(3, 1);
s = 0;

bestLikelihood = 0;
bestMotionVector = [];

% for loops
for theta = thetaSteps
  rotatedpoints = rotate_points(otherPoints, theta);
  for x = xSteps
    xcoords = round((rotatedpoints(1,:) + x + gridOffset) / resolution);
    for y = ySteps
      ycoords = round((rotatedpoints(2,:) + y + gridOffset) / resolution);
      likelihood = sum(map(size(map,1) * (ycoords-1) + xcoords));
      motionVector = [x y theta]';
      K += motionVector * motionVector';
      u += motionVector * likelihood;
      s += likelihood;
      if (likelihood > bestLikelihood)
        bestLikelihood = likelihood;
        bestMotionVector = motionVector;
      end
    end
  end
end

covariance = K * (1. / s) - u * u' * (1. / (s*s));
motion = v2t(bestMotionVector);

end

function rotatedpoints = rotate_points(points, angle)
c = cos(angle);
s = sin(angle);
m = [c -s; s c];
rotatedpoints = m * points;
end

function sparsedPoints = sparsify_points(points, reqDist)
reqDistSqr = reqDist^2;
idx = zeros(size(points, 2), 1);
idx(1) = 1;
lastUsedPoint = 1;
for i = 2:size(points, 2)
  aux = points(:, lastUsedPoint) - points(:, i);
  distToLastSqr = dot(aux, aux);
  if distToLastSqr > reqDistSqr
    lastUsedPoint = i;
    idx(i) = 1;
  end
end
sparsedPoints = points(:,idx>0);
end
