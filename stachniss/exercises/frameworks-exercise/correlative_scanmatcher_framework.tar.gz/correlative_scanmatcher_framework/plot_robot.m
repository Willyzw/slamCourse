function plot_robot(robotPose, color = 'r')

radius = 0.5;
segments = linspace(0,2*pi,32)'; 
circsx = radius .* cos(segments) + robotPose(1); 
circsy = radius .* sin(segments) + robotPose(2); 
linePoints = [robotPose(1) robotPose(2);
radius * cos(robotPose(3)) + robotPose(1), radius * sin(robotPose(3)) + robotPose(2)];
plot(circsx, circsy, 'Color', color, linePoints(:,1), linePoints(:, 2), 'Color', color);

end
